from pyds import MassFunction, powerset
import numpy 
import matplotlib.pyplot as plt
import pandas as pd
import pickle
gas = 0
feed = 0
gas_i=0
feed_i=0
import array as arr
i=0
f_d = arr.array('i', [0, 0, 0, 0, 0]) 
# Importing the dataset
dataset = pd.read_csv('fuzzy2.csv',sep=",",  header=None ,  usecols=[0,1,2,3])
gas_c = dataset.iloc[:, 0].values
feed_c = dataset.iloc[:, 2].values
print(gas_c)
print(feed_c)
limit=5000
for index, i in zip(range(limit), gas_c):
    if i >= 0 and i < 9:
        gas=1
    if i >= 9 and i < 17:
        gas=2
    if i >= 17 and i < 24:
        gas=3
    if i >= 24 and i < 31:
        gas=4 
    if i  >= 31:
        gas=5
    print(gas)

for index, i in zip(range(limit), feed_c):
    if i >= 0 and i < 3:
        feed=1
    if i >=1.5 and i < 3:
        feed=2
    if i >= 3 and i < 4.5:
        feed=3
    if i >= 4.5 and i < 6:
        feed=4 
    if i  >= 6:
        feed=5
    print(feed)
    f_d[feed-1]=f_d[feed-1]+1
    print(f_d)
      # calculation of gas current P1
    x=0.1
maxx=0
max_ind=0
min_ind=0
min=1000
sum=0
    # calculation of feed current P2
p1 = arr.array('d', [0.0, 0.0, 0.0, 0.0, 0.0]) 
p2 = arr.array('d', [0.0, 0.0, 0.0, 0.0, 0.0]) 
for ind,k in enumerate(f_d):
    sum=sum+k
    if k < min:
        min=k
        min_ind=ind
    if k > maxx:
        maxx = k
        max_ind=ind
print("minimum" + str(min_ind))
min_ind=min_ind+1
print("maximum" + str(max_ind))
max_ind=max_ind+1 
print(gas)
print("hellllooooooooooooooooooooooooo")
if min_ind < max_ind:
    print("min_ind is less than max_ind") 
    if gas >= min_ind or gas <= max_ind:
        gas_i=gas
    elif gas < min_ind:
        gas_i=gas-1
    elif gas > max_ind:
        gas_i=gas+1
else:
    if gas <= min_ind or gas >= max_ind:
        gas_i=gas
    elif gas > min_ind:
        gas_i=gas+1
    elif gas < max_ind:
        gas_i=gas-1

print("ideal gas category",gas_i)
print(f_d)
f_d[gas_i-1]=f_d[gas_i-1]+1 
print(f_d)
for ind,l in enumerate(f_d):
    p1[ind]=l/sum
f_d[gas_i-1]=f_d[gas_i-1]-1 
print(f_d) 
feed_i= max_ind
print("ideal feed category", feed_i)
    #calculate probability 
f_d[feed_i-1]=f_d[feed_i-1]+1 
print("feeeeeeeeeeeeeeeeeeed add")
print(f_d)
for ind,m in enumerate(f_d):
    p2[ind]=m/sum
print("feeeeeeeeeeeeeeeeeeed remove")
f_d[feed_i-1]=f_d[feed_i-1]-1 
print(f_d)
print(p1)
print(p2)
m1 = MassFunction({'c1':p1[0], 'c2':p1[1], 'c3':p1[2], 'c4':p1[3], 'c5' :p1[4]})
m2 = MassFunction({'c1':p2[0], 'c2':p2[1], 'c3':p2[2], 'c4':p2[3], 'c5' :p2[4]})
print("Combine m1 and m2:", m1 & m2)
print("Combine m1 and m2 using sampling:", m1.combine_conjunctive(m2, sample_count=10000))
dict = m1 & m2
print(dict)
del dict['c']
maxval = max(dict.values())
res = [k for k, v in dict.items() if v == maxval]
res_list=list(res)  #convert frozenset to list
print("ideal feed" + str(res) )
res_list = [list(x) for x in res]
if res_list[0][0]=='c':
   feed_i=int(res_list[0][1])
else:
   feed_i=int(res_list[0][0])

 #update feed value in file to be forvarded to anfis (pd.write new data)
f_d[feed_i-1]=f_d[feed_i-1]+1 
print(f_d)