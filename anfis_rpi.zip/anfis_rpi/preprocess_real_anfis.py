import anfis
import membershipfunction
import mfDerivs
import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle

l="yes"
d="yes"
t="yes"
while(1):
    date="d"
    Value=0
    with open("motion_test.csv",'r') as f9:
        first_chars = f9.read(1)
    if first_chars:
        line2=pd.read_csv("motion_test.csv", sep=",",  header=None, usecols=[0,1,2,3])[1:];
        line2.columns=["a","b","c","e"]
        with open("feed_test.json",'r') as f:
            first_char = f.read(1)
        if first_char:
            with open("feed_test.json",'r') as f:
                data = pd.read_json(f,lines=True, keep_default_dates=False)
            ind=0;
            for index,line2 in line2.iterrows():
                if(int(line2['e'])>=0 and data['LOC'][ind]==line2['a'] and data['Date'][ind]==line2['b'] and data['Time'][ind]==line2['c'][0:5]):    
                    print("equal")
                    print(line2["c"])  
                    if(data["Cl"][ind]=="yes"):
                        line2["f"]=1
                    else:
                        line2["f"]=0
                        line2["g"]=data["Cleanliness"][ind]
                        line2["h"]=data["Experience"][ind]
                    if(data["FPE"][ind]=="yes"):
                        line2["i"]=1
                    else:
                        line2["i"]=0
                    if(data["WLE"][ind]=="yes"):
                        line2["j"]=1
                    else:
                        line2["j"]=0
                    if(data["bth"][ind]=="yes"):
                        line2["k"]=1
                    else:
                         line2["k"]=0
                    if(data["lwt"][ind]=="yes"):
                         line2["l"]=1
                    else:
                         line2["l"]=0                            
                    ind=ind+1
                else:
                    line2["f"]="0"
                    line2["g"]="0"
                    line2["h"]="0"
                    line2["i"]="0"
                    line2["j"]="0"
                    line2["k"]="0"
                    line2["l"]="0"
        else:
            for index,line2 in line2.iterrows():
                    line2["f"]="0"
                    line2["g"]="0"
                    line2["h"]="0"
                    line2["i"]="0"
                    line2["j"]="0"
                    line2["k"]="0"
                    line2["l"]="0"
        with open('feed.csv', 'w') as f3:
            f3.write(str(line2["a"])+","+str(line2["b"])+","+str(line2["c"])+","+ str(line2["e"])+","+str(line2["f"])+","+str(line2["g"])+","+ str(line2["h"])+","+str(line2["i"])+","+str(line2["j"])+"," + str(line2["k"])+","+str(line2["l"]))
            f3.write("\n")
        f1=pd.read_csv("gas_test.txt", sep=" ", header=None, usecols=[0,1,2,3])[1:];
        f1.columns=["a","b","c","d"]
        f2=pd.read_csv("feed.csv", sep=",",  header=None)  
        f2.columns=["a","b","c","d","e","f","g","h","i","j","k"]    
        index1=0                
        for index,line1 in f1.iterrows(): 
             if(line1['a']==f2['a'][index1] and line1['b']==f2['b'][index1] and line1['c']==f2['c'][index1]):
                print("EQUAL")
                value=line1['d']
                date=line1['b']
             if(line1['a']!=l and line1['b']!=d and line1['c']!=t):
                with open('Dataset_test.csv', 'w') as f:
                     f.write(str(line1["a"])+","+str(line1["b"])+","+str(line1["c"])+","+str(line1["d"])+"," + str(f2["d"][index1])+","+str(f2["e"][index1])+","+str(f2["f"][index1])+","+str(f2["g"][index1])+","+str(f2["h"][index1])+","+str(f2["i"][index1])+"," + str(f2["j"][index1])+","+str(f2["k"][index1]))
                     f.write("\n")
                     l=line1["a"]
                     d=line1["b"]
                     t=line1["c"]
                datasettest = pd.read_csv("Dataset_test.csv", sep=",",  header=None)
                datasettest.columns=["l","m","n","x","y","a","b","c","d","e","f","g"]
                for index,line1 in datasettest.iterrows():
                     if((line1['a']+line1['d'] == 2) and (line1['b'] > 2)):
                         line1['cl']= 2
                     elif((line1['a']+line1['d'] == 1) and line1['b'] > 3):  
                         line1['cl']= 3
                     else:
                         line1['cl']=line1['b']
                     if((line1['e']+line1['f']+line1['g'] == 3) and (line1['c'] > 2)):
                          line1['ex']= 2
                     elif((line1['e']+line1['f']+line1['g'] == 2) and line1['c'] > 3):  
                          line1['ex']= 3
                     elif((line1['e']+line1['f']+line1['g'] == 1) and line1['c'] > 4):
                         line1['ex']= 4
                     else:
                          line1['ex']=line1['c']
                     Value=(2*line1['cl']+line1['ex'])/2
      
                     with open('fuzzy_new.csv', 'w') as f:
                                f.write(str(line1["l"])+","+str(line1["m"])+","+str(line1["n"])+","+str(line1["x"])+","+str(line1["y"])+","+str(Value))
                                f.write("\n")
                     dataset = pd.read_csv('fuzzy_new.csv',sep=",",  header=None ,  usecols=[0,1,2,3,4,5])
                     XTEST = datasettest.iloc[:, 3:6].values
                     print(XTEST)
                     filename = 'anfis_rasp.sav'
                     loaded_model = pickle.load(open(filename, 'rb'))
                     YTE=anfis.predict(loaded_model,XTEST)
                     YTEST=np.round(YTE)
                     if(YTEST==1):
                         print("clean")
                         OUT="CLEAN"
                     elif(YTEST==2):
                         print("mild")
                         OUT="MILD"
                     elif(YTEST==3):
                         print("smelly")
                         OUT="SMELLY"
                     elif(YTEST==4):
                         print("dirty")
                         OUT="DIRTY"
                     elif(YTEST==5):
                         print("pungent")
                         OUT="PUNGENT"
                     for index,datasettest in datasettest.iterrows():
                         with open('out.txt', 'a') as f4:
                             f4.write(str(datasettest["l"])+" "+str(datasettest["m"])+" "+str(datasettest["n"])+" "+ OUT )
                             f4.write("\n")


