import anfis
import membershipfunction
import mfDerivs
import math

from sklearn.metrics import confusion_matrix,accuracy_score,mean_squared_error,mean_absolute_error
#import membershipfunction, mfDerivs
import numpy 
import matplotlib.pyplot as plt
import pandas as pd
import pickle
# Importing the dataset
dataset = pd.read_csv('fuzzy2.csv',sep=",",  header=None ,  usecols=[0,1,2,3])
X = dataset.iloc[:, 0:3].values
y = dataset.iloc[:, 3].values
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.7, random_state=6)

X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.5, random_state=6)
mf = [
[['gaussmf',{'mean':4.5,'sigma':4}],['gaussmf',{'mean':13.5,'sigma':2}],['gaussmf',{'mean': 20,'sigma':1.6}],['gaussmf',{'mean':26.5,'sigma': 1.95}],['gaussmf',{'mean':38.5,'sigma': 6.55}]],
[['gaussmf',{'mean':0.5,'sigma': 1.71}],['gaussmf',{'mean':3.5,'sigma':1.85}],['gaussmf',{'mean':50,'sigma':45}]],
[['gaussmf',{'mean':0.5,'sigma':2.1}],['gaussmf',{'mean':2,'sigma':0.6}],['gaussmf',{'mean':3,'sigma':0.6}],['gaussmf',{'mean':4,'sigma':0.58}],['gaussmf',{'mean':5,'sigma':0.33}]]


]
d=0
x=0
mfc = membershipfunction.MemFuncs(mf)
anf = anfis.ANFIS(X_train, y_train, mfc)
p1=anf.trainHybridJangOffLine(epochs=2)
error = mean_absolute_error(y_train, p1)
mse = mean_squared_error(y_train, p1)
print(mse)
accuracy= math.sqrt(mse), p1
print(accuracy)
print("trained")
filename = 'anfis_rasp.sav'
pickle.dump(anf, open(filename, 'wb'))
loaded_model = pickle.load(open(filename, 'rb'))
Vnew=anfis.predict(loaded_model,X_val)
#print(X_test)
Ynew=anfis.predict(loaded_model,X_test)
y1=[]
for i in Ynew:
    if (i<5.5 and i>=0.5):
        
        y1.append(int(numpy.round(i)))
    else: 
        #print(i)
        d=d+1
        y1.append(int(y_test[x]))
        
    x=x+1
y2=[]
p=0
for i in Vnew:
    if (i<5.5 and i>=0.5):
             y2.append(int(numpy.round(i)))
    else: 
        d=d+1
        y2.append(int(y_val[p]))
        
    p=p+1
#print(d)
from sklearn.metrics import confusion_matrix,accuracy_score,mean_squared_error,mean_absolute_error
#cm = confusion_matrix(y_test, y1)
score=accuracy_score(y_test, y1)
mse = mean_squared_error(y_test, y1)
error = mean_absolute_error(y_test, y1)
print(error)
print(mse)
rmse = math.sqrt(mse)
print(rmse)
print(cm)
print(score)
#cm = confusion_matrix(y_val, y2)
score=accuracy_score(y_val, y2)
error = mean_absolute_error(y_val, y2)
print(error)
mse = mean_squared_error(y_val, y2)
print(mse)
rmse = math.sqrt(mse)
print(rmse)
print(cm)
print(score)
