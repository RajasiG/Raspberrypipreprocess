import pandas as pd
import numpy as np
dataset = pd.read_csv('Labelled_Dataset.csv')
X = dataset.iloc[:, 3:12].values
y = dataset.iloc[:, 12].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.7, random_state=6)

X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.5, random_state=6)
A=X_test

# Fitting SVM to the Training set
from sklearn.svm import SVC
classifier = SVC(kernel = 'linear', random_state = 6)
classifier.fit(X_train, y_train)
# Predicting the Test set results
y_predv = classifier.predict(X_val)

# Predicting the Test set results
y_pred = classifier.predict(X_test)


date="d"
Value=0
line2=pd.read_csv("motion_test.csv", sep=",",  header=None, usecols=[0,1,2,3])[1:];
line2.columns=["a","b","c","e"]
with open("feed_test.json",'r') as f:
    first_char = f.read(1)
    if first_char:
       with open("feed_test.json",'r') as f:
           data = pd.read_json(f,lines=True, keep_default_dates=False)
         
       ind=0;

       for index,line2 in line2.iterrows():
        print(line2['e'])
        print(line2['a'])
        if(int(line2['e'])>0 and data['LOC'][ind]==line2['a'] and data['Date'][ind]==line2['b'] and data['Time'][ind]==line2['c'][0:5]):    
            print("equal")
            print(line2["c"])  
            line2["f"]=data["Cl"][ind]
            line2["g"]=data["Cleanliness"][ind]
            line2["h"]=data["Experience"][ind]
            if(data["FPE"][ind]=="yes"):
                line2["i"]=1
            else:
                line2["i"]=0
                line2["j"]=data["WLE"][ind]
                line2["k"]=data["bth"][ind]
                line2["l"]=data["lwt"][ind]
            ind=ind+1
        else:
            line2["f"]="0"
            line2["g"]="0"
            line2["h"]="0"
            line2["i"]="0"
            line2["j"]="0"
            line2["k"]="0"
            line2["l"]="0"
    else:
        for index,line2 in line2.iterrows():
            line2["f"]="0"
            line2["g"]="0"
            line2["h"]="0"
            line2["i"]="0"
            line2["j"]="0"
            line2["k"]="0"
            line2["l"]="0"
          
    with open('feed.csv', 'w') as f3:
        f3.write(str(line2["a"])+","+str(line2["b"])+","+str(line2["c"])+","+ str(line2["e"])+","+str(line2["f"])+","+str(line2["g"])+","+ str(line2["h"])+","+str(line2["i"])+","+str(line2["j"])+"," + str(line2["k"])+","+str(line2["l"]))
        f3.write("\n")
    f1=pd.read_csv("gas_test.txt", sep=" ", header=None, usecols=[0,1,2,3])[1:];
    f1.columns=["a","b","c","d"]
    f2=pd.read_csv("feed.csv", sep=",",  header=None)  
    f2.columns=["a","b","c","d","e","f","g","h","i","j","k"]    
    index1=0                
    for index,line1 in f1.iterrows(): 
        if(line1['a']==f2['a'][index1] and line1['b']==f2['b'][index1] and line1['c']==f2['c'][index1]):
            print("EQUAL")
        value=line1['d']
        date=line1['b']
    with open('Dataset_test.csv', 'w') as f:
        f.write(str(line1["a"])+","+str(line1["b"])+","+str(line1["c"])+","+str(line1["d"])+"," + str(f2["d"][index1])+","+str(f2["e"][index1])+","+str(f2["f"][index1])+","+str(f2["g"][index1])+","+str(f2["h"][index1])+","+str(f2["i"][index1])+"," + str(f2["j"][index1])+","+str(f2["k"][index1]))
        f.write("\n")
        


datasettest = pd.read_csv("Dataset_test.csv", sep=",",  header=None)
datasettest.columns=["l","m","n","o","p","q","r","s","t","u","v","w"]
XTEST = datasettest.iloc[:, 3:12].values

YTEST = classifier.predict(XTEST)
if(YTEST==1):
   print("clean")
   OUT="CLEAN"
elif(YTEST==2):
   print("mild")
   OUT="MILD"
elif(YTEST==3):
   print("stinky")
   OUT="SMELLY"
elif(YTEST==4):
   print("dirty")
   OUT="DIRTY"
elif(YTEST==5):
   print("pungent")
   OUT="PUNGENT"
for index,datasettest in datasettest.iterrows():
    with open('out.txt', 'a') as f4:
        f4.write(str(datasettest["l"])+" "+str(datasettest["m"])+" "+str(datasettest["n"])+" "+ OUT )
        f4.write("\n")

