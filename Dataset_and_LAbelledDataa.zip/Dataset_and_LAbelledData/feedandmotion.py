
import pandas as pd
import numpy as np
with open("feedbackapp.json",'r') as f:
    data = pd.read_json(f,lines=True, keep_default_dates=False)
line2=pd.read_csv("motionnew1.csv", sep=",",  header=None, usecols=[0,1,2,3]);
line2.columns=["a","b","c","e"]

ind=0;
for index,line2 in line2.iterrows():
    print(line2['e'])
    if(line2['e']>0 and data['LOC'][ind]==line2['a'] and data['Date'][ind]==line2['b'] and data['Time'][ind]==line2['c'][0:5]):    
        print("equal")
        print(line2["c"])  
        line2["f"]=data["Cl"][ind]
        line2["g"]=data["Cleanliness"][ind]
        line2["h"]=data["Experience"][ind]
        line2["i"]=data["FPE"][ind]
        line2["j"]=data["WLE"][ind]
        line2["k"]=data["bth"][ind]
        line2["l"]=data["lwt"][ind]
        ind=ind+1
    else:
        line2["f"]="Null"
        line2["g"]="Null"
        line2["h"]="Null"
        line2["i"]="Null"
        line2["j"]="Null"
        line2["k"]="Null"
        line2["l"]="Null"
          
    with open('feed.csv', 'a') as f3:
        f3.write(str(line2["a"])+","+str(line2["b"])+","+str(line2["c"])+","+ str(line2["e"])+","+str(line2["f"])+","+str(line2["g"])+","+ str(line2["h"])+","+str(line2["i"])+","+str(line2["j"])+"," + str(line2["k"])+","+str(line2["l"]))
        f3.write("\n")
           
print("feedbackdone") 
