import pandas as pd
import numpy as np
date="d"
sum=0
Value=0
f1=pd.read_csv("gasnew1.txt", sep=" ", header=None, usecols=[0,1,2,3]);
f1.columns=["a","b","c","d"]
f2=pd.read_csv("feed.csv", sep=",",  header=None)  
f2.columns=["a","b","c","d","e","f","g","h","i","j","k"]     
index1=0                
for index,line1 in f1.iterrows():
    if(line1['b']!=date):
    	sum=0
    if (line1['a']==f2['a'][index1] and line1['b']==f2['b'][index1] and line1['c']==f2['c'][index1]):
        print("EQUAL")
        sum=sum+f2['d'][index1]
        f2['d'][index1]=sum
        print(f2['d'][index1])
        value=line1['d']
        if(f2['g'][index1]=="NULL"):
            if value<10:
                Value=1
            elif value>=10 and value<17:
                Value=2
            elif value>=17 and value<23:
                Value=3
            elif value>=23 and value<30:
                Value=4
            else:
                Value=5
        else:
            if(value<10 or (f2["f"][index1]==5 and f2["g"][index1]==5)):
                Value=1
            elif((value>=10 and value<17) or (f2["f"][index1]<=5 and f2["f"][index1]>3 and f2["g"][index1]<=5 and f2["g"][index1]>3)and (sum < 350)):
                Value=2
            elif((value>=17 and value<23) or (f2["f"][index1]<=4 and f2["f"][index1]>2 and f2["g"][index1]<=4 and f2["g"][index1]>2) and (sum >=100 and sum <350)):
                Value=3
            elif((value>=23 and value<30) or (f2["f"][index1]<=3 and f2["f"][index1]>1 and f2["g"][index1]<=3 and f2["g"][index1]>1) and (sum >=350 and sum <500)):
                Value=4
            else:
                Value=5
        date=line1['b']
        with open('Labelled_Dataset.csv', 'a') as f:
            f.write(str(line1["a"])+","+str(line1["b"])+","+str(line1["c"])+","+str(line1["d"])+"," + str(f2["d"][index1])+","+str(f2["e"][index1])+","+str(f2["f"][index1])+","+str(f2["g"][index1])+","+str(f2["h"][index1])+","+str(f2["i"][index1])+"," + str(f2["j"][index1])+","+str(f2["k"][index1])+","+str(Value))
            f.write("\n")
        index1=index1+1  
    

